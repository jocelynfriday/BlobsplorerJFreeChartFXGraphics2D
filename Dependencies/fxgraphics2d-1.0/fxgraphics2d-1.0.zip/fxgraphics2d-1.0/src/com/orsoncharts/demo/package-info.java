/**
 * Some demo applications to show how Orson Charts works.
 */
package com.orsoncharts.demo;
